chrome.devtools.panels.create("Grimoire","resources/logos/logo.png", "src/devtool/init/devtool.html", function(panel) {

});
